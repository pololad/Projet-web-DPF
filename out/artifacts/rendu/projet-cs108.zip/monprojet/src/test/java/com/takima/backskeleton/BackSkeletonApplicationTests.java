package com.takima.backskeleton;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackSkeletonApplicationTests {

	@Test
	void contextLoads() {
	}

}
